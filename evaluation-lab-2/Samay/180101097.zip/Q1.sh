#! /bin/bash
val=$1
declare -a arr
arr[0]=val
val2=0
if [ -z ${arr[0]} ]
then
	echo "error, enter by properly specifying"
else
	while [ ${arr[0]} -ne 0 ]
	do
		r = `expr ${arr[0]} % 10`
		arr[0] = $((${arr[0]} / 10))
		val2 = $((${arr[0]} * 10 + r))
	done

	if [ $val2 == ${arr[0]} ]
	then
		 echo "The number is palindrome"
	else
		 echo "Not palindrome"
	fi
fi

